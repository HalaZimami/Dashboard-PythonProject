from django.apps import AppConfig


class FavBooksAppConfig(AppConfig):
    name = 'fav_books_app'
