from django.apps import AppConfig


class RegLoginAppConfig(AppConfig):
    name = 'reg_login_app'
